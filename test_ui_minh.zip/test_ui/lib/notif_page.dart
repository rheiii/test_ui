import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'notification.dart';
import 'package:test_ui/main.dart';

class NotifPage extends StatefulWidget {
  const NotifPage({Key? key}) : super(key: key);

  @override
  State<NotifPage> createState() => _NotifPageState();
}

class _NotifPageState extends State<NotifPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        foregroundColor: Colors.black,
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Thông báo',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 32),
        ),
        actions: [
          Container(
              padding: const EdgeInsets.only(right: 16),
              child: const Icon(
                Icons.search,
                size: 32,
              )),
        ],
      ),
      body: notifList(),
    );
  }

  Widget notifList() => ListView.builder(
        itemBuilder: (context, index) {
          //final notif = notificationResponse.data![index];
          return notifItem(index);
        },
        itemCount: notificationResponse.data!.length,
      );

  Widget notifItem(index) => Container(
        padding: const EdgeInsets.all(16),
        width: double.infinity,
        color: notificationResponse.data![index].status == Status.read
            ? Colors.white
            : Colors.green.shade50,
        //height: 200,
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Stack(
            children: [
              CircleAvatar(
                  radius: 28,
                  backgroundImage: NetworkImage(
                      notificationResponse.data![index].imageThumb)),
              Positioned(
                bottom: 0,
                right: 0,
                child: CircleAvatar(
                  radius: 12,
                  backgroundColor: Colors.white,
                  child: CircleAvatar(
                      radius: 10,
                      backgroundImage: NetworkImage(
                          '${notificationResponse.data![index].icon}')),
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${notificationResponse.data![index].message?.text}',
                  style: const TextStyle(
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  DateTime.fromMillisecondsSinceEpoch(
                          notificationResponse.data![index].createdAt!)
                      .toString(),
                  style: const TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          const Icon(Icons.more_horiz),
        ]),
      );
}
