import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:test_ui/notif_page.dart';
import 'notification.dart';

late final NotificationResponse notificationResponse;

void main(List<String> args) async {
  WidgetsFlutterBinding.ensureInitialized();

  final String response = await rootBundle.loadString('assets/json/noti.json');
  notificationResponse = NotificationResponse.fromRawJson(response);

  notificationResponse.data?.forEach((element) {
    debugPrint("${element.toJson()}");
    debugPrint("____________________");
  });

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Thông báo',
      theme: ThemeData(
        //useMaterial3: true,
        primarySwatch: Colors.blue,
      ),
      //home: const SignInPage(),
      initialRoute: '/',
      routes: {
        '/': (context) => const NotifPage(),
      },
    );
  }
}
